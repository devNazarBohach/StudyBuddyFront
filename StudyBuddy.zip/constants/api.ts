export const API_BASE_URL = "http://10.81.84.19:8080";
